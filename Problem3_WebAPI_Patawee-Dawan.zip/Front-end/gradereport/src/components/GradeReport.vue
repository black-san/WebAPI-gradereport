<template>
    <div>
        <table>
          <thead>
            <tr>
                <th>GROUP_NAME</th>
                <th>MEMBER_NAME</th>
                <th>SCORE</th>
                <th>GRADE</th>
            </tr>
          </thead>

          <tbody v-for="(group, indexGroup) in groupByGroupId" :key="indexGroup">
                <tr v-for="(member,index) in groupByGroupId[indexGroup]" :key="index">
                    <td :rowspan="groupByGroupId[indexGroup].length + 1" v-if="isTheFirstOfGroup(index)">
                        {{ groupName(member) }}
                    </td>
                    <td>
                        {{ member.Member_Name }}
                    </td>
                    <td>
                        {{ member.Score }}
                    </td>
                    <td>
                        {{ grade(member)}}
                    </td>
                </tr>
                <tr v-if="!group[0].isEmpty">
                    <td class="summaryCell"><b>Average Score = {{averageScore(group)}}</b></td>
                    <td class="summaryCell"><b>Max Score = {{maxScore(group)}}</b></td>
                    <td class="summaryCell"><b>Min Score = {{minScore(group)}}</b></td>
                </tr>
          </tbody>

        </table>


    </div>

</template>

<script>
export default {
    name: 'GradeReport',
    data () {
        return {
            msg: 'dd',
            groups: [],
            members: [],
            groupByGroupId: []
        };
    },
    created() {
        this.fecth()
        console.log("Created")
    },
    computed: {

    },
    methods: {
        async fecth() {
            await this.$store.dispatch("fectchGroup")
            await this.$store.dispatch("fetchMember")
            this.groups = this.$store.state.groups
            this.members = this.$store.state.members
            this.leftJoin()
            this.groupMemberByGroupId()
        },
        groupName (member) {
            var groupObj = this.groups.filter(function(val) {
                return val.Group_Id === member.Group_Id;
            });
            console.log(groupObj)
            return groupObj[0].Group_Name
        },
        grade (member) {
            if(member.Score >= 80) {
                return 'A'
            }
            else if(member.Score >= 70 && member.Score < 80) {
                return 'B'
            }
            else if(member.Score >= 60 && member.Score < 70) {
                return 'C'
            }
            else if(member.Score >= 50 && member.Score < 60) {
                return 'D'
            }
            else if(member.Score === 'N/A') {
                return 'N/A'
            }
            else {
                return 'F'
            }
        },
        leftJoin () {
            var isContained = true
            for(let i = 0; i < this.groups.length; i++) {
                for(let j = 0; j < this.members.length; j++) {
                    if(this.groups[i].Group_Id == this.members[j].Group_Id) {
                        isContained = true
                        break
                    }
                    else {
                        isContained = false
                    }
                }
                if (!isContained) {
                    this.members.push({
                        isEmpty: true,
                        Member_Id: 'N/A',
                        Group_Id: this.groups[i].Group_Id,
                        Member_Name: 'N/A',
                        Score: 'N/A'
                    })
                }
            }
        },
        isTheFirstOfGroup (index) {
            if (index === 0) {
                return true
            }
            else {
                return false
            }
        },
        groupMemberByGroupId () {
            for (var i = 0; i < this.groups.length; i++) {
                var memberArr = []
                for (var j = 0; j < this.members.length; j++) {
                    if (this.members[j].Group_Id === this.groups[i].Group_Id) {
                        memberArr.push(this.members[j])
                    }
                }
                this.groupByGroupId.push(memberArr)
            }
            console.log(this.groupByGroupId)
        },
        averageScore (group) {
            var sum = 0
            for (var i = 0; i < group.length; i++) {
                sum += group[i].Score
            }
            return sum/i
        },
        maxScore (group) {
            var max = 0
            for (var i = 0; i < group.length; i++) {
                if (group[i].Score > max) {
                    max = group[i].Score
                }
            }
            return max
        },
        minScore (group) {
            var min = this.maxScore(group)
            for (var i = 0; i < group.length; i++) {
                if (group[i].Score > min) {
                    min = group[i].Score
                }
            }
            return min
        }
    }
}
</script>
<style>
th {
    background-color:lightpink;
}
table, td, th {
  border: solid black;
}
.summaryCell {
    background-color:lightpink;
}
</style>